#' @useDynLib RMariaDB, .registration = TRUE
#' @importFrom Rcpp sourceCpp
"_PACKAGE"
