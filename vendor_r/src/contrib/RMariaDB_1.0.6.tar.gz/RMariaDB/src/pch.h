#include <Rcpp.h>
#include <mysql.h>

#include <plogr.h>

using namespace Rcpp;
