#include "pch.h"
#include "MariaResultImpl.h"

MariaResultImpl::MariaResultImpl() {
}

MariaResultImpl::~MariaResultImpl() {
}
